package com.sarthak.background_ios_sound;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
