import 'dart:io';

import 'package:audio_service/audio_service.dart';
import 'package:flutter/material.dart';

import 'AudioServiceCustom.dart';

class AudioTesting extends StatefulWidget {
  @override
  _AudioTestingState createState() => _AudioTestingState();
}

_backgroundTaskEntrypoint() {
  AudioServiceBackground.run(() => AudioPlayerTask());
}

class _AudioTestingState extends State<AudioTesting> {

  String a = "50";
  String b = "60";
  String c = "70";
  String d = "80";

  @override
  void initState() {
    initSound();
    super.initState();
  }


  @override
  void dispose() async{
    stop();
    //await AudioService.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Testing Screen'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            RaisedButton(onPressed: () {
              playID(a);
            },
              child: Text('start'),
            ),
            RaisedButton(onPressed: (){playID(b);},
              child: Text('start'),
            ),
            RaisedButton(onPressed: () {
              playID(c);
            },
              child: Text('start'),
            ),
            RaisedButton(onPressed: () {
              playID(d);
            },
              child: Text('start'),
            ),
            RaisedButton(onPressed: () {
             playID2("80", "SpecialLocation_3");
            },
              child: Text('both'),
            ),
            RaisedButton(onPressed: () {
             playID2("50", null);
            },
              child: Text('one'),
            ),
            RaisedButton(onPressed: () {
             playID2(null, "SpecialLocation_1");
            },
              child: Text('two'),
            ),
            RaisedButton(onPressed: play,
              child: Text('start'),
            ),
            RaisedButton(onPressed: play,
              child: Text('stop'),
            ),
          ],
        ),
      ),
    );
  }

}

playID2(String speedLimit,String specialLocation){
  MediaItem mediaItem = MediaItem(id: speedLimit, album: null, title: specialLocation);
  AudioService.playMediaItem(mediaItem);
}


playID(String id){
  AudioService.playFromMediaId(id);
}

play() async{
  if (await AudioService.running) {
    sleep(Duration(seconds: 5));
    AudioService.play();
    print('a');
  } else {
    AudioService.start(backgroundTaskEntrypoint: _backgroundTaskEntrypoint);
    print('b');
  }

  //AudioPlayerTask().onPlay();
}

initSound()async{
  await AudioService.connect();
  start();
  //await AudioService.start(backgroundTaskEntrypoint: _backgroundTaskEntrypoint);
}

start() async => await AudioService.start(backgroundTaskEntrypoint: _backgroundTaskEntrypoint).then((value) => print(value));

stop() => AudioService.stop();

